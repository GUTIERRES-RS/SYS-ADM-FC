DROP TABLE IF EXISTS `backups`;

CREATE TABLE `backups` (
  `id_backup` int(11) NOT NULL AUTO_INCREMENT,
  `id_empresa` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `bkp_db_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `data_hora` datetime DEFAULT NULL,
  `url_download` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id_backup`),
  UNIQUE KEY `id_backups_UNIQUE` (`id_backup`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


DROP TABLE IF EXISTS `empresas`;

CREATE TABLE `empresas` (
  `id_empresa` int(11) NOT NULL AUTO_INCREMENT,
  `nome_fantasia` varchar(255) DEFAULT NULL,
  `cnpj` varchar(255) DEFAULT NULL,
  `fone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_empresa`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO empresas VALUES ('1','EMPRESA PRIMARY LTDA','00.000.000.0001-00','00 90000-0000');
INSERT INTO empresas VALUES ('2','Padaria Pão Nosso','00.000.000.0001-00','00 90000-0000');
INSERT INTO empresas VALUES ('3','HOME LDTA','00.000.000.0001-00','00 90000-0000');
INSERT INTO empresas VALUES ('4','EMPRESA TESTE LTDA','00.000.000.0001-00','00 90000-0000');

DROP TABLE IF EXISTS `lanc_tipos`;

CREATE TABLE `lanc_tipos` (
  `id_lanc_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ativo` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id_lanc_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO lanc_tipos VALUES ('1','1','Receita','1');
INSERT INTO lanc_tipos VALUES ('2','1','Despesa','1');

DROP TABLE IF EXISTS `users_painel`;

CREATE TABLE `users_painel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `ativo` varchar(2) NOT NULL,
  `nivel` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO users_painel VALUES ('1','1','Administrador','admin','c62d929e7b7e7b6165923a5dfc60cb56','1','1');
INSERT INTO users_painel VALUES ('2','2','Teste','Teste','c62d929e7b7e7b6165923a5dfc60cb56','1','2');
INSERT INTO users_painel VALUES ('3','1','Usuario','usuario','c62d929e7b7e7b6165923a5dfc60cb56','1','3');
INSERT INTO users_painel VALUES ('4','2','Otavio','otavio','c62d929e7b7e7b6165923a5dfc60cb56','1','3');
INSERT INTO users_painel VALUES ('5','3','Casa','casa','c62d929e7b7e7b6165923a5dfc60cb56','1','1');
INSERT INTO users_painel VALUES ('6','1','Santamassa','gutierres','c62d929e7b7e7b6165923a5dfc60cb56','1','1');
INSERT INTO users_painel VALUES ('9','1','Administrador','testado','c62d929e7b7e7b6165923a5dfc60cb56','1','1');
INSERT INTO users_painel VALUES ('10','4','testeando','testando','c62d929e7b7e7b6165923a5dfc60cb56','1','2');

DROP TABLE IF EXISTS `users_painel_on`;

CREATE TABLE `users_painel_on` (
  `id_users_painel_on` int(11) NOT NULL AUTO_INCREMENT,
  `users_painel_id` int(11) DEFAULT NULL,
  `users_painel_ip` varchar(45) DEFAULT NULL,
  `users_painel_temp` datetime DEFAULT NULL,
  `users_painel_ativo` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id_users_painel_on`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;								